export const environment = {
  production: false,
  firebase: {
    // projectId: 'dabubble-180',
    // appId: '1:1063885758156:web:55d61b46dbc48905ac6c69',
    // storageBucket: 'dabubble-180.appspot.com',
    // apiKey: 'AIzaSyD1QIosifbrMmf2Cis-tPblgDMk1JJmgGE',
    // authDomain: 'dabubble-180.firebaseapp.com',
    // messagingSenderId: '1063885758156',
    // databaseURL:
    //   'https://dabubble-180-default-rtdb.europe-west1.firebasedatabase.app',
    apiKey: 'AIzaSyAZuqach9UwtPiJAt3hrD8SczbPUPTLC7k',
    authDomain: 'da181-db3ce.firebaseapp.com',
    databaseURL:
      'https://da181-db3ce-default-rtdb.europe-west1.firebasedatabase.app',

    projectId: 'da181-db3ce',
    storageBucket: 'da181-db3ce.appspot.com',
    messagingSenderId: '841958832466',
    appId: '1:841958832466:web:c55e8fcb64fb1425bde28b',
    measurementId: 'G-KT2C4RDV9B',
  },
};
